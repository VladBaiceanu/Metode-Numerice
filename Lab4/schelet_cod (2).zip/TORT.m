function [A, U, b] = TORT(A)
%% Triangularizare ortogonala cu reflectori
% INPUTS:
%   A -- matrice aleatoare de dimensiune (m, n)
%
% OUTPUT:
%   A -- matrice de dimensiune (m, n) peste care
%        se suprascrie matricea superior triunhiulara R
%   U -- matrice de dimensiune (m, p), unde p = min (m − 1, n)
%   b -- vector de dimensiune (p, 1), unde p = min (m − 1, n)

%% SOLUTION START %%

%% SOLUTION END %%

end