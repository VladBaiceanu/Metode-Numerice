function [x] = CMMP(A,b)
%% Problema celor mai mici patrate
% INPUTS:
%   A -- matrice aleatoare de dimensiune (m, n), m>n
%        cu coloane liniar independente    
%   b -- vector aleator de dimensiune (m, 1)
%
% OUTPUT:
%   x -- solutia sistemului liniar supradeterminat A*x=b
%        vector de dimensiune (n, 1)


%% SOLUTION START %%

%% SOLUTION END %%

end